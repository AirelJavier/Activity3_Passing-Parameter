package com.example.sampleconstraintlayout;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityKedua extends AppCompatActivity {
    //mendeklarasikan variabel dengan tipe data TextView
    TextView txEmail, txPassword;
    @Override
    protected void onPostCreate( Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        setContentView(R.layout.activity_kedua);

        //Menghubungkan variabel txEmail dengan componen TextView pada Layout
        txEmail = findViewById(R.id.tvEmail);
        //Menghubungkan variabel txEmail dengan componen TextView pada Layout
        txPassword = findViewById(R.id.tvPassword);

        //mndeklarasikan variabel bundle yang akan digunakan untuk mengambil
        //pesan yang dikirmkan melalui method intent
        Bundle bundle = getIntent().getExtras();

        //membuat variabel string uang digunakan untuk menyimpan data yang
        //dikirimkan dari activity sebelumnya dengan kucni "a"
        String email = bundle.getString("a");

        //membuat variabel string uang digunakan untuk menyimpan data yang
        //dikirimkan dari activity sebelumnya dengan kucni "b"
        String pass = bundle.getString("b");

        //menampilkan value dari variabel email kedalam txEmail
        txEmail.setText(email);

        //menampilkan value dari variabel pass kedalam txPassword
        txPassword.setText(pass);
    }
}
